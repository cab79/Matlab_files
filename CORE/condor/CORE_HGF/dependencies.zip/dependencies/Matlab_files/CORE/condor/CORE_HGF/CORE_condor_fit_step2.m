%% Analysis: Perceptual model fitting
% This function approaches model inversion from an empirical Bayes
% perspective (based on VBA_MFX function in VBA toolbox), 
% whereby within-subject priors are iteratively refined and
% matched to the inferred parent population distribution.
%  Note: all subjects must use the same model
% See: http://mbb-team.github.io/VBA-toolbox/wiki/VBA-MFX/

function CORE_condor_fit_step2

dbstop if error

pth = pwd;

% add toolbox paths
addpath(genpath(fullfile(pth, 'dependencies')))
addpath(genpath(fullfile(pth, 'Data')))

% get input and output file info
CORE_condor_monitor_outputs;

nsub = importdata('nsub.txt');
nmods = importdata('nmods.txt');

if length(nmods) ~= 2
    error('script assumes there are both perceptual and response models that vary')
end

for pm = 1:nmods(1)
    for rm = 1:nmods(2)
        D_fit=struct;
        
        for d = 1:nsub
            
            % input file index
            ii = (pm-1)*nmods(1)*nsub + (rm-1)*nsub + d;

            % create D_fit
            in_fname = ['input' num2str(ii) '.mat'];
            out_fname = ['output' num2str(ii) '.mat'];
            load(in_fname,'u','y','S');
            fit=load(out_fname,'out');
            D_fit(ns).HGF.u=u;
            D_fit(ns).HGF.y=y;
            D_fit(ns).HGF.fit=fit.out;
        end

        % save D_fit,S
        save_dir = fullfile(pwd,'Data/fitted');
        if ~exist(save_dir)
            mkdir(save_dir)
        end
        save(fullfile(save_dir,['D_fit_pm' num2str(pm) '_rm' num2str(rm)]),'D_fit','S')
    end
end
quit

function [in,out] = CORE_condor_monitor_outputs

nowtime = now;
in = dir('input*.mat');

fin=0;
while fin==0
    pause(10)
    out = dir('output*.mat');
    if length(out)==length(in)
        complete = [out(:).bytes]>0 & [out(:).datenum]>nowtime;
        if all(complete)
            fin=1;
        end
        disp(['number of outputs complete: ' num2str(sum(complete)) '/' num2str(length(complete))])
    end
end