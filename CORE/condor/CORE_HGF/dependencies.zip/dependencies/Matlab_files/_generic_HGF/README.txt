Processes behavioural data that are outputs of SCIn (must be formatted as SCIn outputs).
Processes EEG data that are outputs of _generic_eeglab_batch