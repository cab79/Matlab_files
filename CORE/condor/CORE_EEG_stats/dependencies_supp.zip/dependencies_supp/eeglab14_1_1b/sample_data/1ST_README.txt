This directory contains sample data for EEGLAB.
The sample data file for the tutorial can be obtained from 
      http://sccn.ucsd.edu/eeglab/download/eeglab_data.set
(this file may not be included in the EEGLAB distribution because of its size).
