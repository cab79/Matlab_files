function CORE_condor_EEG_job
load input.mat;
[out,S] = bayesreg_crossval(X,Y,S,S.pred_group);
save('output.mat','out','S');